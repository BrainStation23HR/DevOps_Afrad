# Terraform + Kubernetes (AWS EKS) — Modular Infra, Manifests, CI/CD & Observability

This repo is a complete, production-ready starter that:
- Provisions an **EKS** cluster with Terraform (modular).
- Uses an **S3 remote backend** (+ DynamoDB lock table).
- Deploys a sample app with Kubernetes manifests (Kustomize-ready).
- Stores **API keys** as Kubernetes **Secrets** (from GitHub Secrets).
- Sets up **observability**: Prometheus/Grafana (metrics), Loki/Promtail (logs), Tempo (traces), and OpenTelemetry Collector.
- Includes a **GitHub Actions** pipeline to plan/apply Terraform and deploy the app to the cluster.

> Cloud: **AWS**. Region defaults to `ap-south-1` (Mumbai). Change as needed.

---

## Prereqs (Alma Linux)

```bash
# 1) AWS CLI v2
sudo dnf -y install unzip curl git
curl "https://awscli.amazonaws.com/awscli-exe-linux-x86_64.zip" -o "awscliv2.zip"
unzip awscliv2.zip && sudo ./aws/install

# 2) Terraform
sudo dnf -y install dnf-plugins-core
sudo dnf config-manager --add-repo https://rpm.releases.hashicorp.com/RHEL/hashicorp.repo
sudo dnf -y install terraform

# 3) kubectl
curl -LO "https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl"
chmod +x kubectl && sudo mv kubectl /usr/local/bin/

# 4) Helm
curl -fsSL https://raw.githubusercontent.com/helm/helm/main/scripts/get-helm-3 | bash

# 5) Configure AWS credentials (or set up OIDC below)
aws configure
```

---

## Remote Backend Bootstrap (One-time)

Create the S3 bucket and DynamoDB table used by Terraform state/locking. Replace values per your org.

```bash
cd infra/backend-bootstrap
terraform init
terraform apply -auto-approve   -var="aws_region=ap-south-1"   -var="bucket_name=afradhayat-terraform-state"   -var="dynamodb_table=terraform-locks"
```

Note the **bucket name** and **table**; reference them in `infra/terraform/environments/prod/backend.tf`.

---

## Provision EKS

```bash
cd infra/terraform/environments/prod
terraform init      # uses S3 remote backend
terraform plan
terraform apply
```

On success, export kubeconfig:

```bash
aws eks update-kubeconfig --region $(terraform output -raw region) --name $(terraform output -raw cluster_name)
```

---

## Observability Stack (installed by Terraform via Helm)

- **kube-prometheus-stack** (Prometheus, Alertmanager, Grafana)
- **loki** + **promtail** (logs)
- **tempo** (traces)
- **opentelemetry-collector** (gateway)

Grafana credentials:
- user: `admin`
- pass: output from `terraform output grafana_admin_password`

Port-forward Grafana (if no ingress):

```bash
kubectl -n monitoring port-forward svc/kube-prometheus-stack-grafana 3000:80
```

Visit http://localhost:3000

---

## App Deployment (K8s manifests)

```bash
kubectl apply -k k8s/overlays/prod
```

Create the secret from your GitHub Actions automatically, or locally like this:

```bash
kubectl -n app create secret generic weather-api   --from-literal=WEATHER_API_KEY="REPLACE_ME"   --dry-run=client -o yaml | kubectl apply -f -
```

---

## CI/CD (GitHub Actions)

- Push the repo to `github.com/afradhayat/<your-repo>`.
- Add GitHub **repository secrets**:
  - `AWS_ROLE_TO_ASSUME` (ARN of a role with Terraform permissions and EKS access)
  - `AWS_REGION` (e.g., `ap-south-1`)
  - `WEATHER_API_KEY`
- Configure **OIDC** for GitHub → AWS (recommended). See inline comments in workflow.

The pipeline performs:
1. Terraform fmt/validate/plan (on PRs) and apply (on main).
2. Generates kubeconfig and deploys `k8s/overlays/prod`.
3. Creates/updates the `weather-api` secret from GitHub Secrets.
