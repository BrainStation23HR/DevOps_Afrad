# architecture-diagram

This directory contains the Cloud Architecture Diagram and documentation for the scalable e-commerce application requested by the user.

## Deliverables
1. `diagram.mmd` - Mermaid diagram of the architecture (editable)
2. `ARCHITECTURE.md` - Detailed explanation, considerations for handling millions of requests, autoscaling, and cost optimizations


---
